﻿# C-Part-2-TeamWork-Assignment
Team work assignment for course C# Part 2 in Telerik Academy season 2015.



# Мinesweeper is ready.
